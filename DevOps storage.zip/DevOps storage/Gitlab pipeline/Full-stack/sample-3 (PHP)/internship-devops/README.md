Huong dan deploy:
1. Khi merge dev vao pro thi danh tags
2. Sua tag trong file env-pro.sh
3. Len server pull repo devops nay ve (/home/internship-devops)
4. Doi cicd build image xong --> Run file start-docker-pro.sh