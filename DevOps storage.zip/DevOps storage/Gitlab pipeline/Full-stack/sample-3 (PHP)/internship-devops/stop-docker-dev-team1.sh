. ./env-dev.team1.sh
docker-compose -f docker-compose.yml -f docker-compose.dev.team1.yml -p $APP_NAME down
