#!/bin/bash
aws iam attach-role-policy --role-name DevOpsRoles --policy-arn <arn:policy>
